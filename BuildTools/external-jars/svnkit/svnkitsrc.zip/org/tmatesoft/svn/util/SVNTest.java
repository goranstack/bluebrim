/*
 * ====================================================================
 * Copyright (c) 2004-2006 TMate Software Ltd.  All rights reserved.
 *
 * This software is licensed as described in the file COPYING, which
 * you should have received as part of this distribution.  The terms
 * are also available at http://svnkit.com/license.html.
 * If newer versions of this license are posted there, you may use a
 * newer version instead, at your option.
 * ====================================================================
 */
package org.tmatesoft.svn.util;

import java.io.File;

import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.SVNURL;
import org.tmatesoft.svn.core.internal.io.dav.DAVRepositoryFactory;
import org.tmatesoft.svn.core.internal.io.fs.FSRepositoryFactory;
import org.tmatesoft.svn.core.internal.io.svn.SVNRepositoryFactoryImpl;
import org.tmatesoft.svn.core.wc.SVNClientManager;
import org.tmatesoft.svn.core.wc.SVNCommitPacket;


/**
 * @version 1.0
 * @author  TMate Software Ltd.
 */
public class SVNTest {

    public static void main(String[] args) throws SVNException {
        
        String s = SVNURL.parseURIDecoded("file:///C:/test/repos/locked").toDecodedString();
        SVNURL u = SVNURL.parseURIDecoded("file:///C:/test/repos/locked");
        System.out.println(u.setPath("c:/test/repos/x", true).toString());
        System.out.println(s);
        System.exit(0);
        
        DAVRepositoryFactory.setup();
        FSRepositoryFactory.setup();
        SVNRepositoryFactoryImpl.setup();
        
        File root = new File("c:/test/svn/wc/building");
        File f1 = new File(root, "AllTests.java");
        File f2 = new File(root, "intersection");
        File f3 = new File(root, "intersection/BuildingIntersectionMathTest.java");
        
        SVNCommitPacket[] ps = SVNClientManager.newInstance().getCommitClient().doCollectCommitItems(new File[] {f1, f2, f3}, false, true, false, true);
        for (int i = 0; i < ps.length; i++) {
            System.out.println(ps[i]);
            ps[i].dispose();
        }
        

    }

}
