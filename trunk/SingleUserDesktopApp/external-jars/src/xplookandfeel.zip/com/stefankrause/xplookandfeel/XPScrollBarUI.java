// Beta
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	XP Look and Feel														   *
*															                   *
*  (C) Copyright 2002, by Stefan Krause, Taufik Romdhane and Contributors      *
*                                                                              *
*                                                                              *
* The XP Look and Feel started as as extension to the Metouia Look and Feel.   *
* The original header of this file was:                                        *
** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*        Metouia Look And Feel: a free pluggable look and feel for java        *
*                         http://mlf.sourceforge.net                           *
*          (C) Copyright 2002, by Taoufik Romdhane and Contributors.           *
*                                                                              *
*   This library is free software; you can redistribute it and/or modify it    *
*   under the terms of the GNU Lesser General Public License as published by   *
*   the Free Software Foundation; either version 2.1 of the License, or (at    *
*   your option) any later version.                                            *
*                                                                              *
*   This library is distributed in the hope that it will be useful,            *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of             *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                       *
*   See the GNU Lesser General Public License for more details.                *
*                                                                              *
*   You should have received a copy of the GNU General Public License along    *
*   with this program; if not, write to the Free Software Foundation, Inc.,   *
*   59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.                    *
*                                                                              *
*   Original Author:  Taoufik Romdhane                                         *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


package com.stefankrause.xplookandfeel;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JScrollBar;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicScrollBarUI;

import com.stefankrause.xplookandfeel.skin.Skin;
import com.stefankrause.xplookandfeel.skin.SkinSimpleButtonIndexModel;

/**
 * This class represents the UI delegate for the JScrollBar component.
 *
 * @author Taoufik Romdhane
 */
public class XPScrollBarUI extends BasicScrollBarUI {

	/**
	 * The scrollbar's highlight color.
	 */
	private static Color highlightColor;

	/**
	 * The scrollbar's dark shadow color.
	 */
	private static Color darkShadowColor;

	/**
	 * The thumb's shadow color.
	 */
	private static Color thumbShadow;

	/**
	 * The thumb's highlight color.
	 */
	private static Color thumbHighlightColor;

	/** true if thumb is in rollover state */
	protected boolean isRollover=false;
	/** true if thumb was in rollover state */
	protected boolean wasRollover=false;

	/**
	 * The free standing property of this scrollbar UI delegate.
	 */
	private boolean freeStanding = false;

	int scrollBarWidth;
	
	/** the track for a vertical scrollbar */
	private static Skin skinTrackVert;
	/** the track for a horizontal scrollbar */
	private static Skin skinTrackHoriz;

	/** The skin for the track for this instance */
	private Skin skinTrack;


	/** the thumb for a vertical scrollbar */
	private static Skin skinThumbVert;
	/** the thumb for a horizontal scrollbar */
	private static Skin skinThumbHoriz;
	
	/** the thumb skin for this instance */
	private Skin skinThumb;
	private SkinSimpleButtonIndexModel skinThumbIndexModel=new SkinSimpleButtonIndexModel();

	/** the gripper skin for a vertical scrollbar */
	static Skin skinGripperVert;
	/** the gripper skin for a horizontal scrollbar */
	static Skin skinGripperHoriz;

	/** the gripper skin for this instance */
	private Skin skinGripper;
	
	
	public XPScrollBarUI() {
	}

	/**
	 * Installs some default values.
	 * Initializes the metouia dots used for the thumb.
	 */
	protected void installDefaults() {
		scrollBarWidth = XPScrollButton.getSkinUp().getHsize();
		super.installDefaults();
		scrollbar.setBorder(null);
	}


	/**
	 * Creates the UI delegate for the given component.
	 *
	 * @param c The component to create its UI delegate.
	 * @return The UI delegate for the given component.
	 */
	public static ComponentUI createUI(JComponent c) {
		return new XPScrollBarUI();
	}

	JButton decreaseButton, increaseButton;
	/**
	 * Creates the decrease button of the scrollbar.
	 *
	 * @param orientation The button's orientation.
	 * @return The created button.
	 */
	protected JButton createDecreaseButton(int orientation) {
		decreaseButton = new XPScrollButton(orientation,  scrollBarWidth, freeStanding);
		return decreaseButton;
	}

	/**
	 * Creates the increase button of the scrollbar.
	 *
	 * @param orientation The button's orientation.
	 * @return The created button.
	 */
	protected JButton createIncreaseButton(int orientation) {
		increaseButton = new XPScrollButton(orientation,  scrollBarWidth, freeStanding);
		return increaseButton;
	}

	/// From MetalUI

	public Dimension getPreferredSize(JComponent c) {
		if (scrollbar.getOrientation() == JScrollBar.VERTICAL) {
			return new Dimension(scrollBarWidth, scrollBarWidth * 3 + 10);
		} else // Horizontal
			{
			return new Dimension(scrollBarWidth * 3 + 10, scrollBarWidth);
		}

	}

	public void paint(Graphics g, JComponent c) {
		Rectangle trackBounds=getTrackBounds();
		getSkinTrack().draw(g, 0,  trackBounds.x, trackBounds.y,  trackBounds.width, trackBounds.height);

		Rectangle thumbBounds=getThumbBounds();
		int index=skinThumbIndexModel.getIndexForState(c.isEnabled(),isRollover,isDragging);

		getSkinThumb().draw(g, index, thumbBounds.x, thumbBounds.y, thumbBounds.width, thumbBounds.height);

		getSkinGripper().drawCentered(g, index, thumbBounds.x, thumbBounds.y, thumbBounds.width, thumbBounds.height);
		
	}

	public boolean isThumbVisible() {
		if (scrollbar.getOrientation() == JScrollBar.VERTICAL) {
			if (getThumbBounds().height == 0)
				return false;
			else
				return true;
		} else {
			if (getThumbBounds().width == 0)
				return false;
			else
				return true;
		}
	}

	// From BasicUI
    protected TrackListener createTrackListener(){
		return new MyTrackListener();
    }

	/**
	 * Basically does BasicScrollBarUI.TrackListener the right job, it just needs
	 * an additional repaint and rollover management
	 */
	protected class MyTrackListener extends BasicScrollBarUI.TrackListener {
		public void mouseReleased(MouseEvent e) {
			super.mouseReleased(e);
			scrollbar.repaint();
		}

		public void mousePressed(MouseEvent e) {
			super.mousePressed(e);
			scrollbar.repaint();
		}
		public void mouseEntered(MouseEvent e) {
			isRollover=false;
			wasRollover=false;
		    if(getThumbBounds().contains(e.getX(), e.getY())) {
		    	isRollover=true;
		    }
		}
		public void mouseExited(MouseEvent e) {
			isRollover=false;
	    	if (isRollover!=wasRollover)
	    	{
		    	scrollbar.repaint();
		    	wasRollover=isRollover;
	    	}
		}
		public void mouseDragged(MouseEvent e) {
		    if(getThumbBounds().contains(e.getX(), e.getY())) {
		    	isRollover=true;
		    }
			super.mouseDragged(e);
		}
		public void mouseMoved(MouseEvent e) {
		    if(getThumbBounds().contains(e.getX(), e.getY())) {
		    	isRollover=true;
		    	if (isRollover!=wasRollover)
		    	{
			    	scrollbar.repaint();
			    	wasRollover=isRollover;
		    	}
		    } else {
		    	isRollover=false;
		    	if (isRollover!=wasRollover)
		    	{
			    	scrollbar.repaint();
			    	wasRollover=isRollover;
		    	}
		    }
		}
	}
	
	
	
	
	
	
	/**
	 * Returns the skinGripperHoriz.
	 * @return SkinCenteredButton
	 */
	public static Skin getSkinGripperHoriz() {
		if (skinGripperHoriz == null) {
			skinGripperHoriz = new Skin("XPScrollbargriphoriz.res", 4, 0); 
		}
		return skinGripperHoriz;		
	}

	/**
	 * Returns the skinGripperVert.
	 * @return SkinCenteredButton
	 */
	public static Skin getSkinGripperVert() {
		if (skinGripperVert == null) {
			skinGripperVert = new Skin("XPScrollbargripvert.res", 4,0); 
		}
		return skinGripperVert;
	}

	/**
	 * Returns the skinThumbHoriz.
	 * @return SkinInfoButton
	 */
	public static Skin getSkinThumbHoriz() {
		if (skinThumbHoriz == null) {
			skinThumbHoriz = new Skin("XPScrollbarthumbhoriz.res", 4, 4);
		}
		return skinThumbHoriz;	
	}

	/**
	 * Returns the skinThumbVert.
	 * @return SkinInfoButton
	 */
	public static Skin getSkinThumbVert() {
		if (skinThumbVert == null) {
			skinThumbVert = new Skin("XPScrollbarthumbvert.res", 4, 4);
		}
		return skinThumbVert;
	}

	/**
	 * Returns the skinTrackHoriz.
	 * @return Skin
	 */
	public static Skin getSkinTrackHoriz() {
		if (skinTrackHoriz == null) {
			skinTrackHoriz = new Skin("XPScrollbartrackhoriz.res", 1, 0);
		}
		return skinTrackHoriz;
	}

	/**
	 * Returns the skinTrackVert.
	 * @return Skin
	 */
	public static Skin getSkinTrackVert() {
		if (skinTrackVert == null) {
			skinTrackVert = new Skin("XPScrollbartrackvert.res", 1, 0);
		}
		return skinTrackVert;
	}

	/**
	 * Returns the skinTrack.
	 * @return Skin
	 */
	public Skin getSkinTrack() {
		if (skinTrack == null) {
			skinTrack = (scrollbar.getOrientation() == JScrollBar.VERTICAL) ? getSkinTrackVert() : getSkinTrackHoriz();			
		}	
		return skinTrack;
	}

	/**
	 * Returns the skinThumb.
	 * @return Skin
	 */
	public Skin getSkinThumb() {
		if (skinThumb == null) {
			skinThumb = (scrollbar.getOrientation() == JScrollBar.VERTICAL) ? getSkinThumbVert() : getSkinThumbHoriz(); 
		}
		return skinThumb;
	}

	/**
	 * Returns the skinGripper.
	 * @return Skin
	 */
	public Skin getSkinGripper() {
		if (skinGripper == null) {
			skinGripper = (scrollbar.getOrientation() == JScrollBar.VERTICAL) ? getSkinGripperVert() : getSkinGripperHoriz();
		}
		return skinGripper;
	}

}