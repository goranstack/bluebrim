// Beta
package com.stefankrause.xplookandfeel.skin;

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	XP Look and Feel                                                           *
*                                                                              *
*  (C) Copyright 2002, by Stefan Krause                                        *
*                                                                              *
*                                                                              *
*   This library is free software; you can redistribute it and/or modify it    *
*   under the terms of the GNU Lesser General Public License as published by   *
*   the Free Software Foundation; either version 2.1 of the License, or (at    *
*   your option) any later version.                                            *
*                                                                              *
*   This library is distributed in the hope that it will be useful,            *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of             *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                       *
*   See the GNU Lesser General Public License for more details.                *
*                                                                              *
*   You should have received a copy of the GNU General Public License along    *
*   with this program; if not, write to the Free Software Foundation, Inc.,    *
*   59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.                    *
*                                                                              *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


/*
 * Due to rising concerns regaring the usage of Microsoft pictures in the 
 * xp look and feel I decided to obfuscate the pictures and make them available
 * via the class SecretLoad which is not supplied as source code. If you
 * want to extend xp look and feel, please use
 * Image img = java.awt.Toolkit.getDefaultToolkit().createImage(url);
 * to load your images.s 
 *
 * Here's the license for SecretLoader:
// Beta
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*   SecretLoader                                                           *
*                                                                              *
*  (C) Copyright 2002, by Stefan Krause                                        *
*                                                                              *
*   This file is not licensed under the LGPL.                                  *
*   To protected Microsoft's rights for the xp images                          *
*   all images are encrypted and the source code for loading is omitted        *
*   You are not allowed to reengineer this class and / or use the images       *
*   for anything other than the purpose of this look and feel                  *
*   You may not use them on any other operating system than windows xp         *
*                                                                              *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

import java.awt.Graphics;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.util.HashMap;

import javax.swing.JPanel;

/**
 * A cache for the skin images. It is used as a singleton. 
 * 
 */
public class SkinImageCache {
	private static SkinImageCache instance = new SkinImageCache();
	private HashMap map;
	private HashMap iconMap;
	private HashMap bufferedMap;

	static GraphicsConfiguration conf;
	static {
		GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
		conf = ge.getDefaultScreenDevice().getDefaultConfiguration();
	}

	JPanel jf = new JPanel();

	protected SkinImageCache() {
		map = new HashMap();
		iconMap = new HashMap();
        bufferedMap = new HashMap();
	}

    /**
     * Loads the image file with fileName <code>fileName</code> as an automatic image.
     * For images with bitmask transparency or no transparency the image should be
     * hardware accelerated.
     * @param fileName the file name of the image file to load
     * @return Image 
     */
	public Image getAutomaticImage(String fileName) {
		Image ret = (Image) map.get(fileName);
		if (ret == null) {

            Image img=SecretLoader.loadImage(fileName);
			map.put(fileName, img);
			return img;
		}
		return ret;
	}

    /** Loads the image file with fileName <code>fileName</code>.
     * @param fileName the file name of the image file to load
     * @return Image
     */
	public Image getImage(String fileName) {
        return getAutomaticImage(fileName);
	}

    /**
     * Loads the image file with fileName <code>fileName</code> as an buffered image.
     * This is basically not hardware accelerated.
     * @param fileName the file name of the image file to load
     * @return Image
     */
	public BufferedImage getBufferedImage(String fileName) {
		BufferedImage b = (BufferedImage) bufferedMap.get(fileName);
		if (b != null)
			return b;

		Image img = getImage(fileName);

		if (img instanceof BufferedImage) {
			return (BufferedImage) img;
		}

		int w = img.getWidth(null);
		int h = img.getHeight(null);

		BufferedImage img2 = conf.createCompatibleImage(w, h);
		Graphics g = img2.getGraphics();
		g.drawImage(img, 0, 0, w, h, 0, 0, w, h, null);
		bufferedMap.put(fileName, img2);
		return img2;
	}

    /**
     * Returns the only instance of the image cache
     * @return SkinImageCache
     */
	public static SkinImageCache getInstance() {
		return instance;
	}

}
