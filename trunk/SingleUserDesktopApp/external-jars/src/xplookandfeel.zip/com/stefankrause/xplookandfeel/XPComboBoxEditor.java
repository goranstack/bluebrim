// Beta
/** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	XP Look and Feel                                                       *
*                                                                              *
*  (C) Copyright 2002, by Stefan Krause                                        *
*                                                                              *
*                                                                              *
*   This library is free software; you can redistribute it and/or modify it    *
*   under the terms of the GNU Lesser General Public License as published by   *
*   the Free Software Foundation; either version 2.1 of the License, or (at    *
*   your option) any later version.                                            *
*                                                                              *
*   This library is distributed in the hope that it will be useful,            *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of             *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                       *
*   See the GNU Lesser General Public License for more details.                *
*                                                                              *
*   You should have received a copy of the GNU General Public License along    *
*   with this program; if not, write to the Free Software Foundation, Inc.,    *
*   59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.                    *
*                                                                              *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package com.stefankrause.xplookandfeel;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;

import javax.swing.border.AbstractBorder;
import javax.swing.plaf.metal.MetalComboBoxEditor;

import com.stefankrause.xplookandfeel.skin.Skin;


/**
 * The standard editor for a combo box
 */
public class XPComboBoxEditor extends MetalComboBoxEditor {

	static Skin skin;
	  
    public XPComboBoxEditor() {
        super();			
        editor.setBorder( new AbstractBorder() {
			/**
			 * @see javax.swing.border.Border#getBorderInsets(java.awt.Component)
			 */
			public Insets getBorderInsets(Component c) {
				  return new Insets(3, 5, 3, 5);
			}

			/**
			 * @see javax.swing.border.Border#paintBorder(java.awt.Component, java.awt.Graphics, int, int, int, int)
			 */
			public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
				
                int index = c.isEnabled() ? 0 : 1;
				getSkin().draw(g, index, x,y,w+5,h);		
			}
		});
    }

    public Skin getSkin()
    {
        if (skin == null) {
			skin =new Skin("XPTextbox.res", 2, 3);
			
		}

		return skin;   
    }

    /**
     * A subclass of BasicComboBoxEditor that implements UIResource.
     * BasicComboBoxEditor doesn't implement UIResource
     * directly so that applications can safely override the
     * cellRenderer property with BasicListCellRenderer subclasses.
     * <p>
     * <strong>Warning:</strong>
     * Serialized objects of this class will not be compatible with
     * future Swing releases. The current serialization support is
     * appropriate for short term storage or RMI between applications running
     * the same version of Swing.  As of 1.4, support for long term storage
     * of all JavaBeans<sup><font size="-2">TM</font></sup>
     * has been added to the <code>java.beans</code> package.
     * Please see {@link java.beans.XMLEncoder}.
     */
    public static class UIResource extends XPComboBoxEditor
    implements javax.swing.plaf.UIResource {
    }
}


