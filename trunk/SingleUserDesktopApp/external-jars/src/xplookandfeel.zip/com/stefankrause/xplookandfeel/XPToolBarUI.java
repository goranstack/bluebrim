// Beta
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	XP Look and Feel														   *
*															                   *
*  (C) Copyright 2002, by Stefan Krause, Taufik Romdhane and Contributors      *
*                                                                              *
*                                                                              *
* The XP Look and Feel started as as extension to the Metouia Look and Feel.   *
* The original header of this file was:                                        *
** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*        Metouia Look And Feel: a free pluggable look and feel for java        *
*                         http://mlf.sourceforge.net                           *
*          (C) Copyright 2002, by Taoufik Romdhane and Contributors.           *
*                                                                              *
*   This library is free software; you can redistribute it and/or modify it    *
*   under the terms of the GNU Lesser General Public License as published by   *
*   the Free Software Foundation; either version 2.1 of the License, or (at    *
*   your option) any later version.                                            *
*                                                                              *
*   This library is distributed in the hope that it will be useful,            *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of             *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                       *
*   See the GNU Lesser General Public License for more details.                *
*                                                                              *
*   You should have received a copy of the GNU General Public License along    *
*   with this program; if not, write to the Free Software Foundation, Inc.,   *
*   59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.                    *
*                                                                              *
*   Original Author:  Taoufik Romdhane                                         *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


package com.stefankrause.xplookandfeel;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;

import javax.swing.AbstractButton;
import javax.swing.JComponent;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.metal.MetalToolBarUI;

import com.stefankrause.xplookandfeel.skin.Skin;

/**
 * This class represents the UI delegate for the JToolBar component.
 *
 * @author Taoufik Romdhane
 */
public class XPToolBarUI extends MetalToolBarUI
{
	/**
	 * The Border used for buttons in a toolbar
	 */
  private Border border=new EmptyBorder(4,4,4,4);

  /**
   * The only UI delegate.
   */
  private final static XPToolBarUI toolBarUI = new XPToolBarUI();
  /** The skin for the background of a toolbar*/
  private static Skin skin;

  /**
   * These insets are forced inner margin for the toolbar buttons.
   */
  private Insets insets = new Insets(2, 2, 2, 2);

  /**
   * Creates the UI delegate for the given component.
   *
   * @param c The component to create its UI delegate.
   * @return The UI delegate for the given component.
   */
  public static ComponentUI createUI(JComponent c)
  {
    return toolBarUI;
  }

  /**
   * Installs some default values for the given toolbar.
   * The gets a rollover property.
   *
   * @param c The reference of the toolbar to install its default values.
   */
  public void installUI(JComponent c)
  {
    super.installUI(c);
    c.putClientProperty("JToolBar.isRollover", Boolean.TRUE);
  }


  /**
   * Paints the given component.
   *
   * @param g The graphics context to use.
   * @param c The component to paint.
   */
  public void paint(Graphics g, JComponent c)
  {
  	getSkin().draw(g, 0, c.getWidth(),c.getHeight());
  }

  
  /**
   * Sets the border of the given component to a rollover border.
   *
   * @param c The component to set its border.
   */
  protected void setBorderToRollover(Component c)
  {
		if (c instanceof AbstractButton) {
			AbstractButton b = (AbstractButton) c;
			b.setBorder(border);
		    b.putClientProperty("JToolBar.isToolbarButton", Boolean.TRUE);
		}

  }
	protected void setBorderToNormal(Component c) {
		if (c instanceof AbstractButton) {
			AbstractButton b = (AbstractButton) c;
			b.setBorder(border);
		    b.putClientProperty("JToolBar.isToolbarButton", Boolean.TRUE);
		}
	}

//    protected Border createRolloverBorder() {
//		return new XPButtonBorder();
//    }
//
//    /**
//     * Creates the non rollover border for toolbar components. This
//     * border will be installed as the border for components added
//     * to the toolbar if rollover borders are not enabled.
//     * <p>
//     * Override this method to provide an alternate rollover border.
//     *
//     * @since 1.4
//     */
//    protected Border createNonRolloverBorder() {
//		return new XPButtonBorder();
//    }
 
	public Skin getSkin() {
		if (skin==null)
			skin= new Skin("XPToolbarBackground.res", 1, 1);
		return skin;
	}
	 
}