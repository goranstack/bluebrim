// Beta
/** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	XP Look and Feel														   *
*															                   *
*  (C) Copyright 2002, by Stefan Krause, Taufik Romdhane and Contributors      *
*                                                                              *
*                                                                              *
* The XP Look and Feel started as as extension to the Metouia Look and Feel.   *
* The original header of this file was:                                        *
** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*        Metouia Look And Feel: a free pluggable look and feel for java        *
*                         http://mlf.sourceforge.net                           *
*          (C) Copyright 2002, by Taoufik Romdhane and Contributors.           *
*                                                                              *
*   This library is free software; you can redistribute it and/or modify it    *
*   under the terms of the GNU Lesser General Public License as published by   *
*   the Free Software Foundation; either version 2.1 of the License, or (at    *
*   your option) any later version.                                            *
*                                                                              *
*   This library is distributed in the hope that it will be useful,            *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of             *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                       *
*   See the GNU Lesser General Public License for more details.                *
*                                                                              *
*   You should have received a copy of the GNU General Public License along    *
*   with this program; if not, write to the Free Software Foundation, Inc.,    *
*   59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.                    *
*                                                                              *
*   Original Author:  Taoufik Romdhane                                         *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package com.stefankrause.xplookandfeel;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JToggleButton;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.metal.MetalButtonUI;

import com.stefankrause.xplookandfeel.skin.Skin;
import com.stefankrause.xplookandfeel.skin.SkinToggleButtonIndexModel;

/**
 * This class represents the UI delegate for the JButton component.
 *
 * @author Taoufik Romdhane
 */
public class XPButtonUI extends MetalButtonUI {

	public static final boolean HINT_DO_NOT_PAINT_TOOLBARBUTTON_IF_NO_MOUSE_OVER = true;
	/**
	 * The Cached UI delegate.
	 */
	private static final XPButtonUI buttonUI = new XPButtonUI();

	/** the skin  for buttons */
	static Skin skinButton;
	
	private static Skin skinToolbar;
	
	/** the index model. Allow default buttons */
	SkinToggleButtonIndexModel buttonIndexModel=new SkinToggleButtonIndexModel(true);
    /** the index model. Forbid default buttons */
    SkinToggleButtonIndexModel toolbarIndexModel=new SkinToggleButtonIndexModel();

	/** the stroke for the fcouse */
	static BasicStroke focusStroke=new BasicStroke(1.0f,BasicStroke.CAP_BUTT,BasicStroke.JOIN_BEVEL,1.0f, new float[] {1.0f, 1.0f}, 1.0f);

	public XPButtonUI() {
		//		timer=TimerFactory.getTimer();
	}

	protected void paintFocus(Graphics g, AbstractButton b, Rectangle viewRect, Rectangle textRect, Rectangle iconRect) {
		Graphics2D g2d=(Graphics2D)g;
		Rectangle focusRect = b.getBounds();

		
		g.setColor(Color.black);
		g2d.setStroke(focusStroke);

		g2d.drawLine(2 , 			 	 2, 		       2 + focusRect.width - 5, 2);
		g2d.drawLine(2, 2+focusRect.height - 5, 2 + focusRect.width - 5, 2+focusRect.height - 5);
		g2d.drawLine(2 , 			 	 2, 		       2 , 2+focusRect.height - 5);
		g2d.drawLine(2 + focusRect.width - 5, 			 	 2, 		       2+ focusRect.width - 5 , 2+focusRect.height - 5);

	}

	/**
	 * Creates the UI delegate for the given component.
	 *
	 * @param c The component to create its UI delegate.
	 * @return The UI delegate for the given component.
	 */
	public static ComponentUI createUI(final JComponent c) {
		if (c instanceof JButton) {
			JButton b = (JButton) c;
			b.setRolloverEnabled(true);
		} else if (c instanceof JToggleButton) {
                JToggleButton b = (JToggleButton) c;
                b.setRolloverEnabled(true);
        }

//     If we used an transparent toolbutton skin we would have to add:       
		c.setOpaque(false);
        c.addPropertyChangeListener("opaque",new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
                c.setOpaque(false);
			}
		});
		return buttonUI;
	}

    /**
     * We don't want to paint the pressed state here - the skin does it for us. 
     * @see javax.swing.plaf.basic.BasicButtonUI#paintButtonPressed(Graphics, AbstractButton)
     */
	protected void paintButtonPressed(Graphics g, AbstractButton b) {
	}

	public void paint(Graphics g, JComponent c) {

		AbstractButton button = (AbstractButton) c;

		if (button.getClientProperty("JToolBar.isToolbarButton") == Boolean.TRUE) {
                toolbarIndexModel.setButton(button);
                int index=toolbarIndexModel.getIndexForState();
				getSkinToolbar().draw(g, index, button.getWidth(),	button.getHeight());
//			}
		} else {
			
			buttonIndexModel.setButton(button);
            buttonIndexModel.setCheckForDefaultButton(button instanceof JButton);
			int index=buttonIndexModel.getIndexForState();
			getSkinButton().draw(g,	index,	button.getWidth(),	button.getHeight());
		}
		super.paint(g, c);

		//		double el=timer.stop();
		//		System.out.println("Painting took "+el+" [msec] ");
	}
	
	public Skin getSkinButton() {
		if (skinButton==null)
			skinButton=new Skin("XPButton.res", 9, 4);
		return skinButton;
	}
    public Skin getSkinToolbar() {
        if (skinToolbar==null)
            skinToolbar= new Skin("XPToolbar.res",8, 4);
        return skinToolbar;
    }
    
    public void update(Graphics g, JComponent c) {
        paint(g, c);
    }
}