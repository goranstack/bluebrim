// Beta
/** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*   XP Look and Feel                                                           *
*                                                                              *
*  (C) Copyright 2002, by Stefan Krause                                        *
*                                                                              *
*                                                                              *
*   This library is free software; you can redistribute it and/or modify it    *
*   under the terms of the GNU Lesser General Public License as published by   *
*   the Free Software Foundation; either version 2.1 of the License, or (at    *
*   your option) any later version.                                            *
*                                                                              *
*   This library is distributed in the hope that it will be useful,            *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of             *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                       *
*   See the GNU Lesser General Public License for more details.                *
*                                                                              *
*   You should have received a copy of the GNU General Public License along    *
*   with this program; if not, write to the Free Software Foundation, Inc.,    *
*   59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.                    *
*                                                                              *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


package com.stefankrause.xplookandfeel;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;

import javax.swing.UIManager;
import javax.swing.border.AbstractBorder;
import javax.swing.plaf.UIResource;

import com.stefankrause.xplookandfeel.skin.Skin;

/**
 * A frame for internal frames
 *
 */
public class XPInternalFrameBorder extends AbstractBorder implements UIResource {
	
    /** indicates whether the internal frame is active */
    boolean isActive;
	
    public XPInternalFrameBorder() {
	}

	/** insets of the frame */
	private static final Insets insets = new Insets(0, 5, 5, 5);

    /** the skin for the left side */
	static Skin skinLeft;
    /** the skin for the upper left side */
	static Skin skinLeftTop;
    /** the skin for the right side */
	static Skin skinRight;
    /** the skin for the upper right side */
	static Skin skinRightTop;
    /** the skin for the bottom side */
	static Skin skinBottom;
	
    /**
     * Uses the skins to paint the border
     * @see javax.swing.border.Border#paintBorder(Component, Graphics, int, int, int, int)
     */
	public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
		int frameTitleHeight = UIManager.getInt("InternalFrame.frameTitleHeight");

        int index=isActive ? 0 : 1;

        getSkinLeftTop().draw(g, index, 5, frameTitleHeight);

		g.translate(0, frameTitleHeight);
        getSkinLeft().draw(g, index, 5, h - frameTitleHeight - 5);
		g.translate(0, -frameTitleHeight);

		g.translate(0, h - 5);
        getSkinBottom().draw(g, index, w, 5);
		g.translate(0, - (h - 5));

		g.translate(w - 5, 0);

        getSkinRightTop().draw(g, index, 5, frameTitleHeight);

		g.translate(0, frameTitleHeight);
        getSkinRight().draw(g, index, 5, h - frameTitleHeight - 5);
		g.translate(0, -frameTitleHeight);

		g.translate(- (w - 5), 0);
	}

    /**
     * 
     * @see javax.swing.border.Border#getBorderInsets(Component)
     */
	public Insets getBorderInsets(Component c) {
		return insets;
	}

    /**
     *  inform the border whether the internal frame is active or not
     * @param isActive
     */
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}


    public Skin getSkinLeft() {
        if (skinLeft==null) skinLeft= new Skin("frameLeft.res", 2,0);
        return skinLeft;
    }
    public Skin getSkinRight() {
        if (skinRight==null) skinRight= new Skin("frameRight.res", 2,0);
        return skinRight;
    }

    public Skin getSkinBottom() {
        if (skinBottom==null) skinBottom= new Skin("frameBottom.res", 2,0);
        return skinBottom;
    }
    public Skin getSkinLeftTop() {
        if (skinLeftTop==null) 
            skinLeftTop= new Skin("frameTopLeft.res", 2,0);
        return skinLeftTop;
    }
    public Skin getSkinRightTop() {
        if (skinRightTop==null) skinRightTop= new Skin("frameTopRight.res", 2,0);
        return skinRightTop;
    }
}