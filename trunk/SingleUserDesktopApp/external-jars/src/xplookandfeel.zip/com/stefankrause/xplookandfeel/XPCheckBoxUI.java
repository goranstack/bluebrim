// Beta
/** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	XP Look and Feel														   *
*															                   *
*  (C) Copyright 2002, by Stefan Krause, Taufik Romdhane and Contributors      *
*                                                                              *
*                                                                              *
* The XP Look and Feel started as as extension to the Metouia Look and Feel.   *
* The original header of this file was:                                        *
** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*        Metouia Look And Feel: a free pluggable look and feel for java        *
*                         http://mlf.sourceforge.net                           *
*          (C) Copyright 2002, by Taoufik Romdhane and Contributors.           *
*                                                                              *
*   This library is free software; you can redistribute it and/or modify it    *
*   under the terms of the GNU Lesser General Public License as published by   *
*   the Free Software Foundation; either version 2.1 of the License, or (at    *
*   your option) any later version.                                            *
*                                                                              *
*   This library is distributed in the hope that it will be useful,            *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of             *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                       *
*   See the GNU Lesser General Public License for more details.                *
*                                                                              *
*   You should have received a copy of the GNU General Public License along    *
*   with this program; if not, write to the Free Software Foundation, Inc.,   *
*   59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.                    *
*                                                                              *
*   Original Author:  Taoufik Romdhane                                         *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package com.stefankrause.xplookandfeel;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;

import javax.swing.AbstractButton;
import javax.swing.JComponent;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.metal.MetalCheckBoxUI;

/**
 * This class represents the UI delegate for the JCheckBox component.
 *
 * @author Taoufik Romdhane
 */
public class XPCheckBoxUI extends MetalCheckBoxUI {

	/**
	 * The Cached UI delegate.
	 */
	private final static XPCheckBoxUI checkBoxUI = new XPCheckBoxUI();

	/**
	 * Creates the UI delegate for the given component.
	 *
	 * @param c The component to create its UI delegate.
	 * @return The UI delegate for the given component.
	 */
	public static ComponentUI createUI(JComponent c) {
		return checkBoxUI;
	}

	/**
	 * Installs some default values for the given button.
	 * The button border is replaced by a metouia border.
	 *
	 * @param button The reference of the button to install its default values.
	 */

	static XPCheckBoxIcon skinnedIcon = new XPCheckBoxIcon();

	public void installDefaults(AbstractButton button) {
		super.installDefaults(button);
		icon = skinnedIcon;
		button.setRolloverEnabled(true);
	}

	static BasicStroke focusStroke = new BasicStroke(1.0f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 1.0f, new float[] { 1.0f/ 1.0f }, 1.0f);

	protected void paintFocus(Graphics g, Rectangle t, Dimension arg2) {
		Graphics2D g2d = (Graphics2D) g;
		g2d.setColor(Color.black);
		g2d.setStroke(focusStroke);
//		g2d.drawRect(t.x - 1, t.y - 1, t.width + 1, t.height + 1);

		g2d.drawLine(t.x -1, 			 t.y -1, 		       t.x -1 + t.width+1,  t.y -1);
		g2d.drawLine(t.x -1, 			 t.y -1 + t.height+1,    t.x -1 + t.width+1,  t.y -1 + t.height+1);
		g2d.drawLine(t.x -1,   t.y -1, 			   t.x -1, 				 t.y -1 + t.height+1);
		g2d.drawLine(t.x -1 + t.width+1,   t.y -1, 			   t.x -1 + t.width+1, 	 t.y -1 + t.height+1);

	}

}