// Beta
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	XP Look and Feel														   *
*															                   *
*  (C) Copyright 2002, by Stefan Krause, Taufik Romdhane and Contributors      *
*                                                                              *
*                                                                              *
* The XP Look and Feel started as as extension to the Metouia Look and Feel.   *
* The original header of this file was:                                        *
** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*        Metouia Look And Feel: a free pluggable look and feel for java        *
*                         http://mlf.sourceforge.net                           *
*          (C) Copyright 2002, by Taoufik Romdhane and Contributors.           *
*                                                                              *
*   This library is free software; you can redistribute it and/or modify it    *
*   under the terms of the GNU Lesser General Public License as published by   *
*   the Free Software Foundation; either version 2.1 of the License, or (at    *
*   your option) any later version.                                            *
*                                                                              *
*   This library is distributed in the hope that it will be useful,            *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of             *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                       *
*   See the GNU Lesser General Public License for more details.                *
*                                                                              *
*   You should have received a copy of the GNU General Public License along    *
*   with this program; if not, write to the Free Software Foundation, Inc.,   *
*   59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.                    *
*                                                                              *
*   Original Author:  Taoufik Romdhane                                         *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


package com.stefankrause.xplookandfeel;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.Insets;

import javax.swing.ImageIcon;
import javax.swing.UIDefaults;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.plaf.InsetsUIResource;
import javax.swing.plaf.basic.BasicBorders;
import javax.swing.plaf.metal.MetalLookAndFeel;
import javax.swing.plaf.metal.MetalTheme;

import com.stefankrause.xplookandfeel.borders.XPPopupMenuBorder;
import com.stefankrause.xplookandfeel.borders.XPTextFieldBorder;
import com.stefankrause.xplookandfeel.skin.SkinImageCache;

/**
 * The XP look and feel. There's a special property to switch the support for
 * rounded windows of internal frames on or off:
 * Use xplookandfeel.roundedWindows = false to turn this support off. It causes
 * slower rendering especially in the case of dragging the internal frame. 
 * By default it is tuned on. 
 *
 * @author Taoufik Romdhane, Stefan Krause
 */
public class XPLookAndFeel extends MetalLookAndFeel
{
  /**
   * The current Metouia compatible theme.
   */
  protected static XPDefaultTheme xpTheme;

  /**
   * The installation state of the Metouia Look and Feel.
   */
  private static boolean isInstalled = false;

  /**
   * The installation state of the Metouia Theme.
   */
  private static boolean themeHasBeenSet = false;

  /**
   * This constructor installs the Metouia Look and Feel with the default color
   * theme.
   */
  public XPLookAndFeel()
  {
	String roundedWindows=System.getProperty("xplookandfeel.roundedWindows");
	if (roundedWindows!=null && roundedWindows.equals("false") )
	{
		XPInternalFrameUI.allowRoundedWindows=false;	
	}
	
    if (!isInstalled)
    {
      isInstalled = true;
      UIManager.installLookAndFeel(
        new UIManager.LookAndFeelInfo(
          "XPLookAndFeel",
          "com.stefankrause.xplookandfeel.XPLookAndFeel"));
    }
  }

  /**
   * Return a string that identifies this look and feel.  This string
   * will be used by applications/services that want to recognize
   * well known look and feel implementations.  Presently
   * the well known names are "Motif", "Windows", "Mac", "Metal".  Note
   * that a LookAndFeel derived from a well known superclass
   * that doesn't make any fundamental changes to the look or feel
   * shouldn't override this method.
   *
   * @return The Metouia Look and Feel identifier.
   */
  public String getID()
  {
    return "XPLookAndFeel";
  }

  /**
   * Return a short string that identifies this look and feel, e.g.
   * "CDE/Motif".  This string should be appropriate for a menu item.
   * Distinct look and feels should have different names, e.g.
   * a subclass of MotifLookAndFeel that changes the way a few components
   * are rendered should be called "CDE/Motif My Way"; something
   * that would be useful to a user trying to select a L&F from a list
   * of names.
   *
   * @return The look and feel short name.
   */
  public String getName()
  {
    return "XPLookAndFeel";
  }

  /**
   * Return a one line description of this look and feel implementation,
   * e.g. "The CDE/Motif Look and Feel".   This string is intended for
   * the user, e.g. in the title of a window or in a ToolTip message.
   *
   * @return The look and feel short description.
   */
  public String getDescription()
  {
    return "XPLookAndFeel: A faked luna look and feel.";
  }

  /**
   * If the underlying platform has a "native" look and feel, and this
   * is an implementation of it, return true.  For example a CDE/Motif
   * look and implementation would return true when the underlying
   * platform was Solaris.
   */
  public boolean isNativeLookAndFeel()
  {
    return true;
  }

  /**
   * Return true if the underlying platform supports and or permits
   * this look and feel.  This method returns false if the look
   * and feel depends on special resources or legal agreements that
   * aren't defined for the current platform.
   */
  public final boolean isSupportedLookAndFeel()
  {
  	String osName=(String)(System.getProperty("os.name") );
    return osName.equals("Windows XP");
  }

  /**
   * Initializes the uiClassID to BasicComponentUI mapping.
   * The JComponent classes define their own uiClassID constants. This table
   * must map those constants to a BasicComponentUI class of the appropriate
   * type.
   *
   * @param table The ui defaults table.
   */
  protected void initClassDefaults(UIDefaults table)
  {
    super.initClassDefaults(table);
    table.putDefaults(new Object[]
    {
      "ButtonUI", "com.stefankrause.xplookandfeel.XPButtonUI",
      "CheckBoxUI", "com.stefankrause.xplookandfeel.XPCheckBoxUI",
      "TextFieldUI", "com.stefankrause.xplookandfeel.XPTextFieldUI",
      "FormattedTextFieldUI", "com.stefankrause.xplookandfeel.XPTextFieldUI",
      "SliderUI", "com.stefankrause.xplookandfeel.XPSliderUI",
      "SpinnerUI", "com.stefankrause.xplookandfeel.XPSpinnerUI",
      "ToolBarUI", "com.stefankrause.xplookandfeel.XPToolBarUI",
      "MenuBarUI", "com.stefankrause.xplookandfeel.XPMenuBarUI",
      "MenuUI", "com.stefankrause.xplookandfeel.XPMenuUI",
      "MenuItemUI", "com.stefankrause.xplookandfeel.XPMenuItemUI",
 	  "CheckBoxMenuItemUI", "com.stefankrause.xplookandfeel.XPCheckBoxMenuItemUI",
      "RadioButtonMenuItemUI", "com.stefankrause.xplookandfeel.XPRadioButtonMenuItemUI",

      "ScrollBarUI", "com.stefankrause.xplookandfeel.XPScrollBarUI",
      "TabbedPaneUI", "com.stefankrause.xplookandfeel.XPTabbedPaneUI",
      "ToggleButtonUI", "com.stefankrause.xplookandfeel.XPButtonUI",
      "ScrollPaneUI", "com.stefankrause.xplookandfeel.XPScrollPaneUI",
      "ProgressBarUI", "com.stefankrause.xplookandfeel.XPProgressBarUI",
      "InternalFrameUI", "com.stefankrause.xplookandfeel.XPInternalFrameUI",
      "RadioButtonUI", "com.stefankrause.xplookandfeel.XPRadioButtonUI",
      "ComboBoxUI", "com.stefankrause.xplookandfeel.XPComboBoxUI",
      "PopupMenuSeparatorUI","com.stefankrause.xplookandfeel.XPPopupMenuSeparatorUI",
      "SplitPaneUI","com.stefankrause.xplookandfeel.XPSplitPaneUI",
      "FileChooserUI", "com.stefankrause.xplookandfeel.XPFileChooserUI",
    });
  }

  /**
   * Creates the default theme and installs it.
   * The XPDefaultTheme is used as default.
   */
  protected void createDefaultTheme()
  {
    if (!themeHasBeenSet)
    {
      xpTheme = new XPDefaultTheme();
      setCurrentTheme(xpTheme);
    }
  }

  /**
   * Sets the current color theme.
   * Warning: The them must be an instance of XPDefaultTheme!
   *
   * @param theme The theme to install.
   */
  public static void setCurrentTheme(MetalTheme theme)
  {
    MetalLookAndFeel.setCurrentTheme(theme);
    themeHasBeenSet = true;
  }

  /**
   * Initializes the system colors.
   *
   * @param table The ui defaults table.
   */
  protected void initSystemColorDefaults(UIDefaults table)
  {
    super.initSystemColorDefaults(table);
    table.put("textHighlight", getTextHighlightColor());
  }

  /**
   * Initializes the default values for many ui widgets and puts them in the
   * given ui defaults table.
   * Here is the place where borders can be changed.
   *
   * @param table The ui defaults table.
   */
  protected void initComponentDefaults(UIDefaults table)
  {
    /* As you can see this is still work in progress... */
    // Let Metal Look and Feel do the basic and complete initializations:
    super.initComponentDefaults(table);

    // Replace the Metal borders:
    Border border;
  	border= new EmptyBorder(0,0,0,0); //4, 16, 4, 16);
//    border=new EmptyBorder(4, 16, 4, 16);
  	table.put("Button.margin", new InsetsUIResource(4, 16, 4, 16)); //MetouiaBorderUtilities.getButtonBorder());
    table.put("Button.border", new BasicBorders.MarginBorder()); //MetouiaBorderUtilities.getButtonBorder());    
  	table.put("ToggleButton.margin", new InsetsUIResource(4, 16, 4, 16)); //, MetouiaBorderUtilities.getButtonBorder());
    table.put("ToggleButton.border", new BasicBorders.MarginBorder()); //new BasicBorders.MarginBorder()); //, MetouiaBorderUtilities.getButtonBorder());
    table.put("TextField.border", new XPTextFieldBorder()); //MetouiaBorderUtilities.getTextFieldBorder());
    table.put("Spinner.border", new XPTextFieldBorder(new Insets(2,2,2,2))); //MetouiaBorderUtilities.getTextFieldBorder());
  	border=new EmptyBorder(2, 2, 2, 2);
    table.put("ToolBar.border", border); //border); //MetouiaBorderUtilities.getButtonBorder()); //new MetouiaToolBarBorder());
//    table.put("MenuBar.border", new EmptyBorder(20,2,2,2));
    table.put("InternalFrame.border", border); //new XPInternalFrameBorder() );
    table.put("InternalFrame.paletteBorder", border); //new XPInternalFrameBorder()); //new XPInternalFrameBorder()); //XPInternalFrameBorder());
    table.put("InternalFrame.optionDialogBorder", border); //new XPInternalFrameBorder()); //new XPInternalFrameBorder()); //XPInternalFrameBorder());
//    table.put("InternalFrame.paletteBorder", new MetouiaPaletteBorder());
//    table.put("InternalFrame.optionDialogBorder", new MetouiaOptionDialogBorder());
    border = new EmptyBorder(2,4,2,4); 
    table.put("Menu.border", border);
    table.put("MenuItem.border", border);
    table.put("CheckBoxMenuItem.border", border);
    table.put("RadioButtonMenuItem.border", border);
    border = new XPPopupMenuBorder();
    table.put("PopupMenu.border", border);
//    table.put("TableHeader.cellBorder", new MetouiaTableHeaderBorder()); 
  	
  	table.put("ScrollPane.border", new LineBorder(new Color(127,157,185),1)); //new MetouiaScrollPaneBorder());

    // Tweak some subtle values:
    table.put("SplitPane.dividerSize", new Integer(6));
    table.put("InternalFrame.paletteTitleHeight", new Integer(10));
    table.put("InternalFrame.frameTitleHeight", new Integer(21));
    table.put("InternalFrame.normalTitleFont",new Font("Trebuchet MS",Font.BOLD,13));
    
	// TabbedPane
//FontUIResource
//TabbedPane.font
//ColorUIResource:
//TabbedPane.shadow
// TabbedPane.darkShadow
	//TabbedPane.focus
//	table.put("TabbedPane.background", Color.red);
//	table.put("TabbedPane.foreground", Color.green);
//	table.put("TabbedPane.highlight", Color.blue);
//	table.put("TabbedPane.shadow", Color.pink);
//	table.put("TabbedPane.darkShadow", Color.cyan);
//	table.put("TabbedPane.lightHighlight", Color.yellow);
//	table.put("TabbedPane.textIconGap",new Integer(20));
//	table.put("TabbedPane.tabInsets",new Insets(40,0,0,0));
//	table.put("TabbedPane.selectedTabPadInsets",new Insets(2, 1, 1, 2)); 	// OK
	table.put("TabbedPane.selectedTabPadInsets",new Insets(2, 2, 2, 3)); 	// OK
//	table.put("TabbedPane.tabAreaInsets",new Insets(4, 2, 0, 6)); // OK
	table.put("TabbedPane.tabAreaInsets",new Insets(4, 2, 0, 0)); // OK
//	table.put("TabbedPane.tabInsets",new Insets(20,20,20,20)); // OK
//	table.put("TabbedPane.contentBorderInsets",new Insets(20,20,20,20)); // OK
	
	table.put("TabbedPane.contentBorderInsets",new Insets(1,1,3,3)); // OK 
//	table.put("TabbedPane.contentBorderInsets",new Insets(1,1,3,3)); // OK 
//	table.put("TabbedPane.tabRunOverlay",new Integer(20));


//    "TabbedPane.contentBorderInsets", tabbedPaneContentBorderInsets,
//    table.put("Button.select", xpTheme.getPressedBackground());
//    table.put("RadioButton.select", xpTheme.getPressedBackground());
//    table.put("ToggleButton.select", xpTheme.getPressedBackground());
    table.put("Checkbox.select", xpTheme.getPressedBackground());
    table.put("TabbedPane.unselected", xpTheme.getPressedBackground());
    table.put("PopupMenu.background", new Color(0,255,0));//xpTheme.getMenuBackground());
    table.put("PopupMenu.foreground", new Color(255,0,0)); 
    
    table.put("TextField.selectionForeground", Color.white);
    table.put("TextField.selectionBackground", new Color(49,106,197));
    
    table.put("TextField.background", Color.white);
    table.put("TextField.disabledBackground", new Color(236,233,216));


    table.put("ComboBox.foreground", Color.black); 
    table.put("ComboBox.background", Color.white); 
    table.put("ComboBox.selectionForeground", Color.white); 
    table.put("ComboBox.selectionBackground", new Color(49,106,197)); 
    table.put("ComboBox.focusBackground", new Color(49,106,197)); 
    

    // Change some icons:
//    table.put("InternalFrame.icon", loadIcon("default.res", this));
//    table.put("InternalFrame.paletteCloseIcon", loadIcon("pclose.res", this));
//    table.put("InternalFrame.closeIcon", loadIcon("close.res", this));
//    table.put("InternalFrame.maximizeIcon", loadIcon("maximize.res", this));
//    table.put("InternalFrame.iconifyIcon", loadIcon("minimize.res", this));
//    table.put("InternalFrame.minimizeIcon", loadIcon("restore.res", this));
    table.put("InternalFrame.frameTitleHeight",new Integer(25));
  	table.put("InternalFrame.paletteTitleHeight",new Integer(16));
  	
    table.put("InternalFrame.icon",loadIcon("XPInternalFrameIcon.res",this));
    
    table.put("ToolTip.background",new Color(255,255,225));
    table.put("ToolTip.foreground",new Color(0,0,0));
    table.put("ToolTip.font",xpTheme.getControlTextFont());
    table.put("ToolTip.border",new CompoundBorder(new LineBorder(Color.black,1), new EmptyBorder(2,2,2,2)));
    
    table.put("Tree.selectionForeground",Color.white );
    table.put("Tree.selectionBackground",new Color(49,106,197) );
    table.put("Tree.expandedIcon",loadIcon("XPTreeMinus.res",this) );
    table.put("Tree.collapsedIcon",loadIcon("XPTreePlus.res",this) );
    table.put("Tree.openIcon",loadIcon("XPTreeFolderOpened.res",this) );
    table.put("Tree.closedIcon",loadIcon("XPTreeFolderClosed.res",this) );
    table.put("Tree.leafIcon",loadIcon("XPTreeLeaf.res",this) );

  	table.put("List.selectionForeground",Color.white );
  	table.put("List.selectionBackground",new Color(49,106,197) );

    
    table.put("FileView.directoryIcon",loadIcon("XPTreeFolderClosed.res",this) );
    table.put("FileView.computerIcon",loadIcon("XPComputerIcon.res",this) );
    table.put("FileView.fileIcon",loadIcon("XPDocument.res",this) );
    table.put("FileView.floppyDriveIcon",loadIcon("XPFloppy.res",this) );
    table.put("FileView.hardDriveIcon",loadIcon("XPHarddisk.res",this) );
    
    table.put("FileChooser.detailsViewIcon",loadIcon("XPFileDetails.res",this) );
    table.put("FileChooser.homeFolderIcon",loadIcon("XPDesktopIcon.res",this) );
    table.put("FileChooser.listViewIcon",loadIcon("XPFileList.res",this) );
    table.put("FileChooser.newFolderIcon",loadIcon("XPNewFolder.res",this) );
    table.put("FileChooser.upFolderIcon",loadIcon("XPParentDirectory.res",this) );
    table.put("FileChooser.upFolderIcon",loadIcon("XPParentDirectory.res",this) );
           
           
	table.put("OptionPane.errorIcon", loadIcon("XPError.res",this) );
	table.put("OptionPane.informationIcon", loadIcon("XPInformation.res",this) );
	table.put("OptionPane.warningIcon", loadIcon("XPWarning.res",this) );
	table.put("OptionPane.questionIcon", loadIcon("XPQuestion.res",this) );           
//    Tree.leafIcon
    
//    table.put("RadioButton.icon", new UIDefaults.ProxyLazyValue("com.stefankrause.xplookandfeel.MetouiaIconFactory","getRadioButtonIcon"));

//	"ScrollBar.darkShadow",.getSecondary1()
  }

  /**
   * Loads an image icon.
   *
   * @param file The image file name.
   * @param invoker The refence of the invoking class, whose classloader will be
   *                used for loading the image.
   */
  public static ImageIcon loadIcon(final String file, final Object invoker)
  {
  	// When we return an IconUIResource the disabled icon of a file choose won't be painted greyed out,
  	// thus we simply stay with an icon
  	return loadIconImmediately(file,invoker); //LookAndFeel.makeIcon(XPLookAndFeel.class,"icons/"+file);
  }

  /**
   * Loads an image icon immediately.
   *
   * @param file The image file name.
   * @param invoker The refence of the invoking class, whose classloader will be
   *                used for loading the image.
   */
  public static ImageIcon loadIconImmediately(String file, Object invoker)
  {
    try
    {
       Image img=SkinImageCache.getInstance().getImage(file);
       ImageIcon icon = new ImageIcon(img);
      /*Toolkit.getDefaultToolkit().createImage(
        readStream(invoker.getClass().getResourceAsStream(file))));*/
       if (icon.getIconWidth()<=0) {
          	System.out.println("******************** File "+file+" not found. Exiting");
          	System.exit(1);
      }
      return icon;
    }
    catch (Exception exception)
    {
      exception.printStackTrace();
      System.out.println("Error getting resource " + file);
      return null;
    }
  }
  
  public static Color getLightControl() {
  	return xpTheme.getControlHighlight();	
  }
  
  /**
   * used for SliderUI Ticks
   */
  public static Color getDarkControl() {
  	return xpTheme.getDarkControl();
  }
}