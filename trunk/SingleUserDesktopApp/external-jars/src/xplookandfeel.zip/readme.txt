XP Look And Feel
================


This is beta 2 of the XP Look And Feel

Changes sinice beta 1:

* New: Included new UI classes for JSpinner
* Resolved: Resource loading could fail under certain conditions (compressed jar, webstart)
* Resolved: Buttons for internal frames were sometimes not loaded
* Changed: To reduce the size of the library the resource files (i.e. the images for the skin) 
  are only included in the xplookandfeel.jar

Important note:
* To avoid troubles regarding the license I decided to obfuscate the skins (*.res files). The loader
  for the skins is not included as source code for this purpose. 

Read the license.txt for license information.

For comments, suggestions or bug reports don't hesitate to send an email to Stefan.Krause@gmx.at !

