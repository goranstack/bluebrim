This file comes with the src distribution for Crimson.  Please see the
following items for more information:

  + http://xml.apache.org/crimson for general project information
  + build.xml file for build instructions using Ant
